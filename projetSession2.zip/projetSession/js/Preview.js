function ShowPreview() {
    var preview = document.getElementById("previewFrame");

    preview.style.display = "block";
}

function HidePreview() {
    var preview = document.getElementById("previewFrame");

    preview.style.display = "none";
}
