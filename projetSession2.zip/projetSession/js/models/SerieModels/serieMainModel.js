/**
 * Created by Kevin on 2015-11-04.
 */
define([
    'underscore',
    '../../backbone'
], function(_, Backbone){
    var SeasonMainModel = Backbone.Model.extend({
    });

    return SeasonMainModel;
});