/**
 * Created by Kevin on 2015-11-05.
 */
define([
    'underscore',
    '../../backbone'
], function(_, Backbone){
    var EpisodeModel = Backbone.Model.extend({
    });

    return EpisodeModel;
});