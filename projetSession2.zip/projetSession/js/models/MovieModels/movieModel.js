/**
 * Created by khrysiale on 15-11-06.
 */
define([
    'underscore',
    '../../backbone'
], function(_, Backbone){
    var MovieModel = Backbone.Model.extend({

    });

return MovieModel;
});