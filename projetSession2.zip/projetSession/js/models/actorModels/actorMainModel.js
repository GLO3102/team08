/**
 * Created by Kevin on 2015-11-02.
 */
define([
    'underscore',
    'backbone'
], function(_, Backbone){
    var ActorMainModel = Backbone.Model.extend({
    });

    return ActorMainModel;
});