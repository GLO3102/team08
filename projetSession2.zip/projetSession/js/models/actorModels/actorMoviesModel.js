/**
 * Created by Kevin on 2015-11-02.
 */
define([
    'underscore',
    'backbone'
], function(_, Backbone){
    var ActorMoviesModel = Backbone.Model.extend({
    });

    return ActorMoviesModel;
});